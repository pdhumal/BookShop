function p2()
{
	
	window.location = "page3.html";
}