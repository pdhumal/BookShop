
 function totalPrice()
        {
            var q = document.getElementById("quant").value;
            if (q == 0)
            {
                alert("Please enter a valid input");
                return;
            }
            else
            {
            	var t=q*250;
            }
           document.getElementById("result").innerHTML = t;
            
            var price = 100;
            var q = document.getElementById("quant").value;
            document.getElementById("result").value = price * q;
            alert("Your total Price = "+(price*q));
 
        }

        function displayOutput()
        {
            alert("Bookd Ordered Successfully..!!");
        }
